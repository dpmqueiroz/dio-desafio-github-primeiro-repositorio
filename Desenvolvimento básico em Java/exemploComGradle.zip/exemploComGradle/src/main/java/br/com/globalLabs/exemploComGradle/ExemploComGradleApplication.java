package br.com.globalLabs.exemploComGradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploComGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploComGradleApplication.class, args);
	}

}
