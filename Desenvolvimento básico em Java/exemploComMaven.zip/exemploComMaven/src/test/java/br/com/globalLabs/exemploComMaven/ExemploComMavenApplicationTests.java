package br.com.globalLabs.exemploComMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploComMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
